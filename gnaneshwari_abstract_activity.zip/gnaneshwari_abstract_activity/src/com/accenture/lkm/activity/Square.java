package com.accenture.lkm.activity;

public class Square extends TwoDimensionalShape{

	int side;
	
	public Square(String shapeColor,int side){
		this.shapeColor="blue";
		this.side=5;
	}
	@Override
	public
	double computeArea(){
		return side*side;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
	}
	public double computeCircumference(int side) {
		return 4*side;
	}

}
