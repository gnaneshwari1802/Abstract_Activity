package com.accenture.lkm.activity;

public class Rectangle extends TwoDimensionalShape {
	int length, breadth;
	
	public Rectangle(String shapeColor, int length ,int breadth){
		this.shapeColor="green";
		this.length=8;
		this.breadth=9;
	}
	@Override
	public
	double computeArea(){
		return length*breadth;
	}
	
	
}
