package com.accenture.lkm.activity;

abstract class TwoDimensionalShape {
	double shapeArea;
	String shapeColor;
	
	TwoDimensionalShape(){
	this.shapeColor="red";
	}
	void getCordinates(int x, int y)
	{
		System.out.println("Co-ordinates noted "+x+" "+y);
	}
	abstract double computeArea();
		
		
	
}
