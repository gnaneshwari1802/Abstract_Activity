package com.accenture.lkm.ui;
import com.accenture.lkm.activity.*;
public class AbstractMain{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Rectangle r=new Rectangle("white",4,0);
Square s=new Square("pink",56);
System.out.println(r.computeArea());
System.out.println(s.computeArea());
	}

}
